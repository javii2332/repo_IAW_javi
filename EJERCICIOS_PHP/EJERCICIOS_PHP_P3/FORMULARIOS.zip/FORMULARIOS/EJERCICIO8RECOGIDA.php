<?php
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Formularios
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Nombre formulario</h1>

<?php

// Función de recogida de datos

function recoge($key, $type = "")
{
    if (!is_string($key) && !is_int($key) || $key == "") {
        trigger_error("Function recoge(): Argument #1 (\$key) must be a non-empty string or an integer", E_USER_ERROR);
    } elseif ($type !== "" && $type !== []) {
        trigger_error("Function recoge(): Argument #2 (\$type) is optional, but if provided, it must be an empty array or an empty string", E_USER_ERROR);
    }
    $tmp = $type;
    if (isset($_REQUEST[$key])) {
        if (!is_array($_REQUEST[$key]) && !is_array($type)) {
            $tmp = trim(htmlspecialchars($_REQUEST[$key]));
        } elseif (is_array($_REQUEST[$key]) && is_array($type)) {
            $tmp = $_REQUEST[$key];
            array_walk_recursive($tmp, function (&$value) {
                $value = trim(htmlspecialchars($value));
            });
        }
    }
    return $tmp;
}

calculaLetraNIF(int $num): string {
    $calcular = generaNumero() % 23
    $letras = ['T','R','W','A','G','M','Y','F',];
    return $letras[$calcular];
}

//PROGRAMA PRINCIPAL

//PASO 1 RECOJO DATOS DEL FORMULARIO 

$num=recoge('num');
$num=int($num);

//PASO 2
// Hacer las comprobaciones oportunas de los valores y mostrar avisos si los
// valores son vacíos, si no son del tipo correcto, si no están en rango, etc.

$numOk = false;


if ($num == ""){
    print "<p>No has escrito ningún número.</p>\n";
} elseif (!is_numeric($num)) {
    print "<p>NO ES UN NUMERO ENTERO POSITIVO.</p>\n"
} elseif ( $num < 1 || $num > 9999){
    print "<p>Tu numero de DNI no está en el rango entre 1 y 99999999</p>"
} else {
    $numOk =true;
}


//PASO3
// Si todos los valores recogidos del formulario están OK, 
// realizar las accionas que se pida en el ejercicio

print "<p>EL NUMERO DE DNI ES: " . str_pad(generaNumero(), 8, "0", STR_PAD_LEFT) . calculaLetraNIF(generaNumero()) . "</p>\n";

?>
  <p><a href="plantilla1-forms.php">Volver al formulario.</a></p>
</body>
</html>
